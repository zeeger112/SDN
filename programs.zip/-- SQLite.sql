-- SQLite
c.execute("CREATE table users ('id' integer, 'username' text, 'password' text)")
c.execute("INSERT into users values(1, 'jan','Pa$$w0rd')")